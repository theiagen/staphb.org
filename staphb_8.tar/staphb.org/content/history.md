---
title: "History"
date: 2019-12-16T21:06:09Z
draft: false
---

## In the beginning...

Who are we?  How did this all begin?  Well, at first there were four: Kevin Libuit, Sean Wang, Kelly Oakeson, and Joel Sevinsky.  And by four we mean there were at least four of us bothering Heather Carleton for help with bioinformatics of enteric pathogens around winter 2016/2017.  Heather suggested, probably to save herself from answering too many questions and often the same question four times, that the group of should "talk amongst ourselves", and our contact information was shared.  And that was the beginning.

## Our first APHL Annual Meeting - 2017

By the time the APHL Annual Meeting rolled around, our numbers were starting to grow and we had our first in-person informal meetup.

![APHL 2017](/images/staphb-aphl2017.jpg)

## AMD Days 2017

![AMD Day 2017](/images/staphb_amd_2017_small.jpg)
