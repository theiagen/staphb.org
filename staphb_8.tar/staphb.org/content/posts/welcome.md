+++
draft = false
date = 2019-12-15T22:43:04Z
title = "Welcome to the StaPH-B website!"
description = ""
slug = ""
tags = []
categories = []
externalLink = ""
series = []
+++

It has been a long time coming, but we have decided to support a website where we can aggregate all the training and information in genomic epidemiology in one location, as well as provide new and inique content for public health bioinformatics.
